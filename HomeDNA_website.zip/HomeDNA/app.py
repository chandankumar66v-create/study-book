
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path
from datetime import date, datetime

app = Flask(__name__)
app.secret_key = "homedna-demo-secret"
DB = Path(__file__).with_name("homedna.db")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL, category TEXT NOT NULL, amount REAL NOT NULL,
        note TEXT, project_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS projects(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        house_id INTEGER, budget REAL DEFAULT 0, start_date TEXT,
        completion_date TEXT, progress INTEGER DEFAULT 0, status TEXT DEFAULT 'Planning'
    );
    CREATE TABLE IF NOT EXISTS houses(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, house_type TEXT,
        style TEXT, bhk INTEGER, plot_size REAL, built_area REAL, floors INTEGER,
        bathrooms INTEGER, cost REAL, duration INTEGER, image TEXT,
        description TEXT, features TEXT, materials TEXT, labour TEXT
    );
    CREATE TABLE IF NOT EXISTS materials(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, unit TEXT,
        estimated REAL DEFAULT 0, purchased REAL DEFAULT 0, used REAL DEFAULT 0,
        purchase_cost REAL DEFAULT 0, project_id INTEGER
    );
    CREATE TABLE IF NOT EXISTS workers(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, skill TEXT,
        experience INTEGER DEFAULT 0, rating REAL DEFAULT 0, daily_wage REAL DEFAULT 0,
        contact TEXT, availability TEXT DEFAULT 'Available', project_id INTEGER
    );
    CREATE TABLE IF NOT EXISTS maintenance(
        id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT NOT NULL, category TEXT,
        task_date TEXT, cost REAL DEFAULT 0, contractor TEXT, description TEXT,
        warranty TEXT, next_date TEXT
    );
    CREATE TABLE IF NOT EXISTS documents(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT,
        linked_to TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS warranties(
        id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT, provider TEXT,
        expiry TEXT, notes TEXT
    );
    CREATE TABLE IF NOT EXISTS timeline(
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER,
        title TEXT, description TEXT, event_date TEXT
    );
    """)
    if db.execute("SELECT COUNT(*) FROM houses").fetchone()[0] == 0:
        houses = [
        ("Modern 2BHK","Independent Home","Modern",2,1200,950,1,2,2850000,7,
         "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1000",
         "Compact modern home designed for urban family living.",
         "Open kitchen|Large windows|Covered parking|Natural light",
         "Cement|Steel|Bricks|Sand|Tiles|Paint|Electrical wire","Masons|Electrician|Plumber|Painter"),
        ("Modern 3BHK","Independent Home","Modern",3,1800,1450,2,3,4650000,10,
         "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1000",
         "A spacious two-floor family home with a contemporary facade.",
         "3 bedrooms|Balcony|Car parking|Family lounge",
         "Cement|Steel|Bricks|Sand|Tiles|Glass|Wood","Masons|Carpenter|Electrician|Plumber|Painter"),
        ("Premium Villa","Villa","Villa",3,2400,1900,2,4,7200000,14,
         "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1000",
         "Premium villa concept with generous living areas and outdoor space.",
         "Master suite|Garden|Large kitchen|Terrace|Double parking",
         "Cement|Steel|Bricks|Granite|Glass|Wood|Paint","Full construction crew"),
        ("Traditional Indian Home","Independent Home","Traditional",3,2000,1600,1,3,4100000,11,
         "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1000",
         "A warm Indian-inspired home combining traditional character with modern comfort.",
         "Veranda|Courtyard feel|Pooja room|Car parking",
         "Cement|Steel|Bricks|Tiles|Wood|Paint","Masons|Carpenters|Electrician|Plumber"),
        ("Minimalist Duplex","Duplex","Minimalist",4,2200,1750,2,4,5600000,12,
         "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=1000",
         "Minimalist duplex with clean lines, efficient planning and bright interiors.",
         "4 bedrooms|Double-height space|Balcony|Parking",
         "Cement|Steel|Bricks|Glass|Tiles|Paint","Masons|Carpenter|Electrician|Plumber")
        ]
        db.executemany("""INSERT INTO houses
        (name,house_type,style,bhk,plot_size,built_area,floors,bathrooms,cost,duration,image,description,features,materials,labour)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", houses)
    if db.execute("SELECT COUNT(*) FROM projects").fetchone()[0] == 0:
        db.execute("INSERT INTO projects(name,house_id,budget,start_date,completion_date,progress,status) VALUES(?,?,?,?,?,?,?)",
                   ("Demo Modern Home",1,2850000,date.today().isoformat(),None,35,"In Progress"))
    if db.execute("SELECT COUNT(*) FROM materials").fetchone()[0] == 0:
        db.executemany("""INSERT INTO materials(name,unit,estimated,purchased,used,purchase_cost,project_id)
                          VALUES(?,?,?,?,?,?,?)""", [
            ("Cement","bags",900,450,180,162000,1),
            ("Steel","kg",4500,2200,800,165000,1),
            ("Bricks","units",12000,6000,2000,72000,1),
            ("Sand","tons",35,18,7,36000,1),
            ("Tiles","sq.ft",1200,400,0,28000,1)
        ])
    if db.execute("SELECT COUNT(*) FROM workers").fetchone()[0] == 0:
        db.executemany("""INSERT INTO workers(name,skill,experience,rating,daily_wage,contact,availability,project_id)
                          VALUES(?,?,?,?,?,?,?,?)""", [
            ("Ravi Kumar","Mason",9,4.8,950,"9876543210","Assigned",1),
            ("Suresh","Electrician",7,4.6,900,"9876501234","Available",1),
            ("Manoj","Plumber",6,4.5,850,"9876512345","Available",1)
        ])
    db.commit(); db.close()

@app.context_processor
def inject_globals():
    db=get_db()
    income=db.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='Income'").fetchone()[0]
    expense=db.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='Expense'").fetchone()[0]
    projects=db.execute("SELECT * FROM projects ORDER BY id DESC").fetchall()
    db.close()
    return {"income":income,"expense":expense,"balance":income-expense,"nav_projects":projects}

@app.route("/")
def dashboard():
    db=get_db()
    active=db.execute("SELECT COUNT(*) FROM projects WHERE status!='Completed'").fetchone()[0]
    workers=db.execute("SELECT COUNT(*) FROM workers").fetchone()[0]
    materials=db.execute("SELECT COUNT(*) FROM materials").fetchone()[0]
    spending=db.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind='Expense'").fetchone()[0]
    budget=db.execute("SELECT COALESCE(SUM(budget),0) FROM projects").fetchone()[0]
    upcoming=db.execute("SELECT * FROM maintenance WHERE next_date IS NOT NULL ORDER BY next_date LIMIT 5").fetchall()
    recent=db.execute("SELECT * FROM transactions ORDER BY id DESC LIMIT 6").fetchall()
    db.close()
    return render_template("dashboard.html",active=active,workers=workers,materials=materials,spending=spending,budget=budget,upcoming=upcoming,recent=recent)

@app.route("/finances", methods=["GET","POST"])
def finances():
    db=get_db()
    if request.method=="POST":
        kind=request.form["kind"]; amount=float(request.form["amount"])
        db.execute("INSERT INTO transactions(kind,category,amount,note,project_id) VALUES(?,?,?,?,?)",
                   (kind,request.form["category"],amount,request.form.get("note"),request.form.get("project_id") or None))
        db.commit(); flash("Transaction added.","success"); return redirect(url_for("finances"))
    rows=db.execute("SELECT t.*,p.name project FROM transactions t LEFT JOIN projects p ON p.id=t.project_id ORDER BY t.id DESC").fetchall()
    db.close(); return render_template("finances.html",transactions=rows)

@app.post("/finances/delete/<int:id>")
def delete_transaction(id):
    db=get_db(); db.execute("DELETE FROM transactions WHERE id=?",(id,)); db.commit(); db.close()
    return redirect(url_for("finances"))

@app.route("/materials", methods=["GET","POST"])
def materials():
    db=get_db()
    if request.method=="POST":
        cost=float(request.form["cost"]); qty=float(request.form["qty"])
        db.execute("""INSERT INTO materials(name,unit,estimated,purchased,used,purchase_cost,project_id)
                      VALUES(?,?,?,?,?,?,?)""",(request.form["name"],request.form["unit"],float(request.form.get("estimated") or 0),qty,0,cost,request.form.get("project_id") or None))
        db.execute("INSERT INTO transactions(kind,category,amount,note,project_id) VALUES('Expense','Raw Material',?,?,?)",
                   (cost,request.form["name"],request.form.get("project_id") or None))
        db.commit(); flash("Material and expense recorded.","success"); return redirect(url_for("materials"))
    rows=db.execute("SELECT m.*,p.name project FROM materials m LEFT JOIN projects p ON p.id=m.project_id ORDER BY m.id DESC").fetchall()
    db.close(); return render_template("materials.html",materials=rows)

@app.route("/workers", methods=["GET","POST"])
def workers_page():
    db=get_db()
    if request.method=="POST":
        db.execute("""INSERT INTO workers(name,skill,experience,rating,daily_wage,contact,availability,project_id)
                      VALUES(?,?,?,?,?,?,?,?)""",(request.form["name"],request.form["skill"],int(request.form.get("experience") or 0),
                      float(request.form.get("rating") or 0),float(request.form.get("wage") or 0),request.form.get("contact"),
                      request.form.get("availability","Available"),request.form.get("project_id") or None))
        db.commit(); flash("Worker added.","success"); return redirect(url_for("workers_page"))
    rows=db.execute("SELECT w.*,p.name project FROM workers w LEFT JOIN projects p ON p.id=w.project_id ORDER BY w.id DESC").fetchall()
    db.close(); return render_template("workers.html",workers=rows)

@app.route("/projects", methods=["GET","POST"])
def projects_page():
    db=get_db()
    if request.method=="POST":
        db.execute("""INSERT INTO projects(name,house_id,budget,start_date,completion_date,progress,status)
                      VALUES(?,?,?,?,?,?,?)""",(request.form["name"],request.form.get("house_id") or None,float(request.form["budget"]),
                      request.form.get("start_date"),request.form.get("completion_date"),0,"Planning"))
        db.commit(); flash("Project created.","success"); return redirect(url_for("projects_page"))
    rows=db.execute("""SELECT p.*,h.name house FROM projects p LEFT JOIN houses h ON h.id=p.house_id ORDER BY p.id DESC""").fetchall()
    houses=db.execute("SELECT * FROM houses ORDER BY name").fetchall()
    db.close(); return render_template("projects.html",projects=rows,houses=houses)

@app.route("/projects/<int:id>")
def project_details(id):
    db=get_db(); p=db.execute("SELECT p.*,h.name house,h.image FROM projects p LEFT JOIN houses h ON h.id=p.house_id WHERE p.id=?",(id,)).fetchone()
    mats=db.execute("SELECT * FROM materials WHERE project_id=?",(id,)).fetchall()
    ws=db.execute("SELECT * FROM workers WHERE project_id=?",(id,)).fetchall()
    events=db.execute("SELECT * FROM timeline WHERE project_id=? ORDER BY event_date DESC",(id,)).fetchall()
    db.close(); return render_template("project_details.html",project=p,materials=mats,workers=ws,events=events)

@app.route("/catalogue")
def catalogue():
    db=get_db(); q=request.args
    sql="SELECT * FROM houses WHERE 1=1"; params=[]
    if q.get("style"): sql+=" AND style=?"; params.append(q["style"])
    if q.get("bhk"): sql+=" AND bhk=?"; params.append(int(q["bhk"]))
    if q.get("max_cost"): sql+=" AND cost<=?"; params.append(float(q["max_cost"]))
    if q.get("min_area"): sql+=" AND built_area>=?"; params.append(float(q["min_area"]))
    rows=db.execute(sql+" ORDER BY id DESC",params).fetchall(); db.close()
    return render_template("catalogue.html",houses=rows)

@app.route("/house/<int:id>")
def house_details(id):
    db=get_db(); house=db.execute("SELECT * FROM houses WHERE id=?",(id,)).fetchone(); db.close()
    return render_template("house_details.html",house=house)

@app.post("/house/<int:id>/use")
def use_design(id):
    db=get_db(); h=db.execute("SELECT * FROM houses WHERE id=?",(id,)).fetchone()
    cur=db.execute("""INSERT INTO projects(name,house_id,budget,start_date,progress,status)
                      VALUES(?,?,?,?,?,?)""",(h["name"]+" Project",id,h["cost"],date.today().isoformat(),0,"Planning"))
    pid=cur.lastrowid
    for m in h["materials"].split("|"):
        db.execute("INSERT INTO materials(name,unit,estimated,project_id) VALUES(?,?,?,?)",(m,"estimated",0,pid))
    db.execute("INSERT INTO timeline(project_id,title,description,event_date) VALUES(?,?,?,?)",
               (pid,"Project created","Created from House Catalogue design: "+h["name"],date.today().isoformat()))
    db.commit(); db.close(); flash("Project created from this house design.","success")
    return redirect(url_for("project_details",id=pid))

@app.route("/planner", methods=["GET","POST"])
def planner():
    result=None
    if request.method=="POST":
        area=float(request.form["width"])*float(request.form["length"])*float(request.form.get("floors") or 1)
        built=min(area*0.72, area)
        quality={"Basic":1500,"Standard":1900,"Premium":2600}.get(request.form.get("quality","Standard"),1900)
        cost=built*quality
        result={"area":round(built),"cost":round(cost),"duration":max(5,round(built/180))}
    return render_template("planner.html",result=result)

@app.route("/maintenance", methods=["GET","POST"])
def maintenance_page():
    db=get_db()
    if request.method=="POST":
        db.execute("""INSERT INTO maintenance(task,category,task_date,cost,contractor,description,warranty,next_date)
                      VALUES(?,?,?,?,?,?,?,?)""",(request.form["task"],request.form["category"],request.form.get("task_date"),
                      float(request.form.get("cost") or 0),request.form.get("contractor"),request.form.get("description"),
                      request.form.get("warranty"),request.form.get("next_date")))
        db.commit(); flash("Maintenance record added.","success"); return redirect(url_for("maintenance_page"))
    rows=db.execute("SELECT * FROM maintenance ORDER BY COALESCE(next_date,'9999-12-31')").fetchall()
    db.close(); return render_template("maintenance.html",maintenance=rows)

@app.route("/homeshield")
def homeshield():
    db=get_db(); warranties=db.execute("SELECT * FROM warranties ORDER BY expiry").fetchall(); db.close()
    return render_template("homeshield.html",warranties=warranties)

@app.route("/documents", methods=["GET","POST"])
def documents():
    db=get_db()
    if request.method=="POST":
        db.execute("INSERT INTO documents(name,category,linked_to,notes) VALUES(?,?,?,?)",
                   (request.form["name"],request.form["category"],request.form.get("linked_to"),request.form.get("notes")))
        db.commit(); flash("Document record added.","success"); return redirect(url_for("documents"))
    rows=db.execute("SELECT * FROM documents ORDER BY id DESC").fetchall(); db.close()
    return render_template("documents.html",documents=rows)

@app.route("/passport/<int:project_id>")
def passport(project_id):
    db=get_db()
    p=db.execute("SELECT p.*,h.* FROM projects p LEFT JOIN houses h ON h.id=p.house_id WHERE p.id=?",(project_id,)).fetchone()
    events=db.execute("SELECT * FROM timeline WHERE project_id=? ORDER BY event_date DESC",(project_id,)).fetchall()
    mats=db.execute("SELECT * FROM materials WHERE project_id=?",(project_id,)).fetchall()
    ws=db.execute("SELECT * FROM workers WHERE project_id=?",(project_id,)).fetchall()
    db.close(); return render_template("passport.html",project=p,events=events,materials=mats,workers=ws)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
